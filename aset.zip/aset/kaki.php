</div>
<br>
<div class="foot">
<span class="left"><b>&#169; <?php echo date("Y"); ?> mirror-t</b></span><span class="right"><font class="coded">Coded by [<font color="orange">ironsix</font>] & <font color="orange">PawN0</font></font><span>
</div>
<div class="kelir"></div>
</body>
</html>
