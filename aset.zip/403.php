<?php
// coded by [ironsix] & PawN0
// The Next Level
// 
// Minggu, 12:07:57 24-11-2019
//

$judul = "403";
include 'aset/kepala.php';
include 'aset/heker.php';
?>
<div class="acenter">
<h1>403 <small>Forbidden</small></h1>
<pre>Anda tidak diijinkan mengakses halaman tersebut.</pre>
</div>
<?php
include 'aset/kaki.php';
?>
