<?php
// coded by [ironsix] & PawN0
// The Next Level
// 
// Minggu, 12:07:57 24-11-2019
//

$judul = "404";
include 'aset/kepala.php';
include 'aset/heker.php';
?>
<div class="acenter">
<h1>404 <small>Not Found</small></h1>
<pre>Halaman yang anda coba akses tidak ditemukan.</pre>
</div>
<?php
include 'aset/kaki.php';
?>
